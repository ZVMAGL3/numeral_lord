module.exports = {
	host:'127.0.0.1',//服务器地址
	user:'root',
	password:'WJ5XJJ21~',
	database:'user',
	multipleStatements: true
}