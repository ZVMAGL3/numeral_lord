<template>
    <useBackground/>
</template>

<script setup>
    import useBackground from '/src/components/useBackground.vue'
</script>
 