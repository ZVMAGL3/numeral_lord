import { ref } from 'vue';
import axios from 'axios';

export default function() {
    let url ='https://game.xdline.cn/server/gamespace/nextgame/home/recommendgamev2'
    let headers ={'Authorization': 'b0be072fef6940f1c52e3f6100b1f205f5dc2b328d3f0d73b6fc66fa35682c74cd2f0d7d84155ae9e82cee2dc0461930626c7b6c888998a2211850b09e60bb26'}
    const data = ref(null);
    const error = ref(null);
    const isLoading = ref(false);

    const fetchData = () => {
        isLoading.value = true;
        axios
            .get(url, { headers })
            .then(response => {
                data.value = response.data;
            })
            .catch(err => {
                error.value = err;
            })
            .finally(() => {
                isLoading.value = false;
            });
    };

    return { data, error, isLoading, fetchData };
}