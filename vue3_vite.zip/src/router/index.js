import { createRouter, createWebHashHistory } from 'vue-router';

const routerHistory = createWebHashHistory();

//引入组件
import gamelobby from '/src/pages/gamelobby/gamelobby.vue'

export default new createRouter({
	history:routerHistory,
    routes:[
        {
            path:'/',
            redirect:'gamelobby', 
        },
        {
            path:'/gamelobby',
            name:'gamelobby',
            component:gamelobby
        },
    ]
})