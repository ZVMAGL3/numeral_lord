<template>
    <div>
        registerInfo
    </div>
</template>

<script>
    export default {
        name:'registerInfo',
    }
</script>

<style>

</style>