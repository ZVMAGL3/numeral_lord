<template>
    <div>
        examRegistration
    </div>
</template>

<script>
    export default {
        name:'examRegistration',
    }
</script>

<style>

</style>