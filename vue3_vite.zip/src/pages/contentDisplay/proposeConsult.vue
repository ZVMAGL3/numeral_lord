<template>
    <div>
        proposeConsult
    </div>
</template>

<script>
    export default {
        name:'proposeConsult',
    }
</script>

<style>

</style>