<template>

</template>

<script setup>
    import useApi from '/src/hooks/useApi.js';
    const { data, error, isLoading, fetchData } = useApi()
    
    fetchData()

    setTimeout(() => {
        console.log(data, error, isLoading, fetchData); // 输出最新的数据
    }, 2000);

</script>

<style scoped>

</style>